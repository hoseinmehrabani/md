import tkinter as tk
import sqlite3

def save_info():
    # اتصال به پایگاه داده (یا ایجاد آن اگر وجود نداشته باشد)
    conn = sqlite3.connect('user_info.db')

    # ایجاد یک شیء cursor که برای اجرای دستورات SQL استفاده می شود
    c = conn.cursor()

    # ایجاد یک جدول به نام users اگر وجود نداشته باشد
    c.execute('''
        CREATE TABLE IF NOT EXISTS users
        (first_name TEXT, last_name TEXT)
    ''')

    # ذخیره اطلاعات کاربر در پایگاه داده
    c.execute('''
        INSERT INTO users VALUES (?, ?)
    ''', (first_name_entry.get(), last_name_entry.get()))

    # ذخیره تغییرات در پایگاه داده
    conn.commit()

    # بستن اتصال به پایگاه داده
    conn.close()

root = tk.Tk()
root.title("User Information")

first_name_label = tk.Label(root, text="نام")
first_name_label.pack()
first_name_entry = tk.Entry(root)
first_name_entry.pack()

last_name_label = tk.Label(root, text="نام خانوادگی")
last_name_label.pack()
last_name_entry = tk.Entry(root)
last_name_entry.pack()

submit_button = tk.Button(root, text="ثبت اطلاعات", command=save_info)
submit_button.pack()

root.mainloop()
