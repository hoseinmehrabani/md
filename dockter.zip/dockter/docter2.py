import tkinter as tk
import sqlite3

def save_info():
    # اتصال به پایگاه داده (یا ایجاد آن اگر وجود نداشته باشد)
    conn = sqlite3.connect('user_info.db')
    c = conn.cursor()
    # ایجاد یک جدول به نام users اگر وجود نداشته باشد
    c.execute('''
        CREATE TABLE IF NOT EXISTS users
        (first_name TEXT, last_name TEXT)
    ''')
    # ذخیره اطلاعات کاربر در پایگاه داده
    c.execute('''
        INSERT INTO users VALUES (?, ?)
    ''', (first_name_entry.get(), last_name_entry.get()))
    # ذخیره تغییرات در پایگاه داده
    conn.commit()
    # بستن اتصال به پایگاه داده
    conn.close()
def show_saved_info():
    # اتصال به پایگاه داده
    conn = sqlite3.connect('user_info.db')
    c = conn.cursor()

    # دریافت اطلاعات از جدول users
    c.execute('SELECT * FROM users')
    user_info = c.fetchall()

    # نمایش اطلاعات در یک لیبل
    info_label.config(text="\n".join([f"نام: {row[0]} - نام خانوادگی: {row[1]}" for row in user_info]))

    # بستن اتصال به پایگاه داده
    conn.close()

root = tk.Tk()
root.title("User Information")
first_name_label = tk.Label(root, text="نام")
first_name_label.pack(fill=tk.Y, pady=25)
first_name_entry = tk.Entry(root)
first_name_entry.pack(fill=tk.X, padx=10)
last_name_label = tk.Label(root, text="نام خانوادگی")
last_name_label.pack(fill=tk.X, padx=10)
last_name_entry = tk.Entry(root)
last_name_entry.pack(fill=tk.X, padx=10)
submit_button = tk.Button(root, text="ثبت اطلاعات", command=save_info)
submit_button.pack(fill=tk.X, padx=10)
show_info_button = tk.Button(root, text="نمایش اطلاعات", command=show_saved_info)
show_info_button.pack(fill=tk.X, padx=10)
info_label = tk.Label(root, text="")
info_label.pack(fill=tk.X, padx=10)
"""
root.resizable(True,True)
root.rowconfigure(0, weight=5)
root.columnconfigure(1, weight=5)
first_name_label.rowconfigure(3,weight=1)
first_name_label.columnconfigure(0,weight=1)
"""

root.mainloop()